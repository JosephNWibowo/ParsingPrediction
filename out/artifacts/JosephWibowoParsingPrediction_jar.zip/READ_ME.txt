This parsing prediciton sys1
is run by using windows cmd line :java -jar parsing prediction.jar (argument file name)
the argument file name has to be change either with test.trace/li1.trace/li2.trace

